function calculaSoma(){
        var campo1 = document.getElementById('campo1').value;
         campo1 = parseInt(campo1);
        var campo2 = document.getElementById('campo2').value;
         campo2 = parseInt(campo2);
        var soma = campo1+campo2;
        document.getElementById('mostradorSoma').innerHTML=soma;
}
function compara(){
    var campo1 = document.getElementById('campo1').value;
     campo1 = parseInt(campo1);
    var campo2 = document.getElementById('campo2').value;
     campo2 = parseInt(campo2);
    if(campo1==campo2){
        document.getElementById('comparador').innerHTML=("Ambos são iguais");
        document.getElementById('comparador').style.backgroundColor = "#FFFA00";
    }
    else if(campo1>campo2){
        document.getElementById('comparador').innerHTML=("Primeiro numero é maior");
        document.getElementById('comparador').style.backgroundColor = "#FF0F0F";
    }
    else if(campo1<campo2){
        document.getElementById('comparador').innerHTML=("Segundo numero é maior");
        document.getElementById('comparador').style.backgroundColor = "#31FF4E";
    }
    else{
        document.getElementById('comparador').innerHTML=error;
    }
}
function mostraNumeroLetras(){
        const quantidadeLetras = document.getElementById('campo1').value;
        document.getElementById("contadorLetra").innerHTML =("o tamanho atual do campo é de: " + quantidadeLetras.length);
}
function escreve(){
    var texto = document.getElementById("campo1");
    document.getElementById("mostradorTexto").innerHTML = texto.value;
}

function verifica(){
var radio = document.getElementsByName("formato");
  for(var i = 0; i < radio.length; i++){

    if (radio[i].checked && radio[i].value == "F") {
      document.getElementById("pFisica").style.display = "block";
    
      document.getElementById("pJuridica").style.display = "none";


    } else if (radio[i].checked && radio[i].value == "J") {
      document.getElementById("pJuridica").style.display = "block";


      document.getElementById("pFisica").style.display = "none";


    }
  }
}