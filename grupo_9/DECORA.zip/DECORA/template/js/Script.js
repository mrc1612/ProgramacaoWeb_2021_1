
function logado(usuario) {
    document.getElementById("robo").style.display = "block";
    document.getElementById("cadastroTag").style.display = "block";
    document.getElementById("usuario").style.display = "block";
    document.getElementById("Nusuario").style.display = "none";
    document.getElementById("login").style.display = "none";
    document.getElementById("logout").style.display = "block";

    document.getElementById("usuario").innerHTML = "Usuário: " + usuario;
}

function logadoCRUD(usuario) {
    document.getElementById("robo").style.display = "block";
    document.getElementById("usuario").style.display = "block";
    document.getElementById("Nusuario").style.display = "none";
    document.getElementById("logout").style.display = "block";

    document.getElementById("usuario").innerHTML = "Usuário: " + usuario;
}

function naoLogado() {
    document.getElementById("robo").style.display = "none";
    document.getElementById("cadastroTag").style.display = "none";
    document.getElementById("usuario").style.display = "none";
    document.getElementById("Nusuario").style.display = "block";
    document.getElementById("login").style.display = "block";
    document.getElementById("logout").style.display = "none";
    window.location.href = "/../index.html"
}

function naoLogadoCRUD() {
    document.getElementById("robo").style.display = "none";
    document.getElementById("usuario").style.display = "none";
    document.getElementById("Nusuario").style.display = "block";
    document.getElementById("logout").style.display = "none";
    window.location.href = "../../DECORA/index.html"
}

function logout(telaCRUD) {
    var usuario = getCookie();
    if (usuario != "") {
        if (telaCRUD) {
            apagaCookie();
            naoLogadoCRUD();
        } else {
            apagaCookie();
            naoLogado();
        }
    } else {
        naoLogado();
    }
}

function setaCookie(nomeUsuario) {
    document.cookie="login=" + nomeUsuario + "; path=/";
}

function apagaCookie() {
    document.cookie="login=; path=/";
}

function getCookie() {
    var nomeCookie = "login=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nomeCookie) == 0) return c.substring(nomeCookie.length,c.length);
    }
    return null;
}

function confereCookie(telaCRUD) {
    var usuario=getCookie();
    if (usuario != "" && usuario != null) {
        if (telaCRUD) {
            logadoCRUD(usuario)
        } else {
            logado(usuario)
        }
    } else {
       naoLogado()
    }
}