
function logado(usuario) {
    document.getElementById("robo").style.display = "block";
    document.getElementById("cadastroTag").style.display = "block";
    document.getElementById("usuario").style.display = "block";
    document.getElementById("Nusuario").style.display = "none";
    document.getElementById("login").style.display = "none";
    document.getElementById("logout").style.display = "block";

    document.getElementById("usuario").innerHTML = "Usuário: " + usuario;
}

function logadoCRUD(usuario) {
    document.getElementById("robo").style.display = "block";
    document.getElementById("usuario").style.display = "block";
    document.getElementById("Nusuario").style.display = "none";
    document.getElementById("logout").style.display = "block";

    document.getElementById("usuario").innerHTML = "Usuário: " + usuario;
}

function naoLogado() {
    document.getElementById("robo").style.display = "none";
    document.getElementById("cadastroTag").style.display = "none";
    document.getElementById("usuario").style.display = "none";
    document.getElementById("Nusuario").style.display = "block";
    document.getElementById("login").style.display = "block";
    document.getElementById("logout").style.display = "none";
    window.location.href = "/../index.html";
}

function naoLogadoCRUD() {
    document.getElementById("robo").style.display = "none";
    document.getElementById("usuario").style.display = "none";
    document.getElementById("Nusuario").style.display = "block";
    document.getElementById("logout").style.display = "none";
    window.location.href = "../../DECORA/index.html"
}

function logout(telaCRUD) {
    var usuario = getCookie();
    if (usuario != "") {
        if (telaCRUD) {
            apagaCookie();
            setaCookieLayout("layoutNormal");
            mudaLayout("layoutNormal");
            naoLogadoCRUD();
        } else {
            apagaCookie();
            setaCookieLayout("layoutNormal");
            mudaLayout("layoutNormal");
            naoLogado();
        }
    } else {
        setaCookieLayout("layoutNormal");
        mudaLayout("layoutNormal");
        naoLogado();
    }
}

function logoutMULTIMIDIA() {
    var usuario = getCookie();
    if (usuario != "") {
        apagaCookie();
        setaCookieLayout("layoutNormal");
        mudaLayout("layoutNormal");
        naoLogadoMULTIMIDIA(true);
    } else {
        setaCookieLayout("layoutNormal");
        mudaLayout("layoutNormal");
        naoLogado();
    }
}

function setaCookie(nomeUsuario) {
    document.cookie="login=" + nomeUsuario + "; path=/";
}

function setaCookieLayout(valorLayout) {
    document.cookie="layout=" + valorLayout + "; path=/";
}

function apagaCookie() {
    document.cookie="login=; path=/";
}

function apagaCookieLayout(valorLayout) {
    document.cookie="layout=; path=/";
}

function getCookie() {
    var nomeCookie = "login=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nomeCookie) == 0) return c.substring(nomeCookie.length,c.length);
    }
    return null;
}

function getCookieLayout() {
    var nomeCookie = "layout=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nomeCookie) == 0) return c.substring(nomeCookie.length,c.length);
    }
    return null;
}

function confereCookie(telaCRUD) {
    var usuario=getCookie();
    if (usuario != "" && usuario != null) {
        if (telaCRUD) {
            logadoCRUD(usuario)
        } else {
            logado(usuario)
        }
    } else {
       naoLogado()
    }
}

function logadoMULTIMIDIA(usuario) {
    document.getElementById("robo").style.display = "block";
    document.getElementById("cadastroTag").style.display = "block";
    document.getElementById("usuario").style.display = "block";
    document.getElementById("Nusuario").style.display = "none";
    document.getElementById("login").style.display = "none";
    document.getElementById("logout").style.display = "block";

    document.getElementById("usuario").innerHTML = "Usuário: " + usuario;
}

function naoLogadoMULTIMIDIA(botaoPressionado) {
    document.getElementById("robo").style.display = "none";
    document.getElementById("cadastroTag").style.display = "none";
    document.getElementById("usuario").style.display = "none";
    document.getElementById("Nusuario").style.display = "block";
    document.getElementById("login").style.display = "block";
    document.getElementById("logout").style.display = "none";
    if (botaoPressionado) {
        window.location.href = "../../DECORA/index.html";
    }
}

function confereCookieMULTIMIDIA() {
    var usuario=getCookie();
    if (usuario != "" && usuario != null) {
       logadoMULTIMIDIA(usuario)
    } else {
       naoLogadoMULTIMIDIA(false)
    }
}

function confereCookieLayout() {
    var layout=getCookieLayout();
    if (layout != "" && layout != null) {
        mudaLayout(layout);
    } else {
        // Deixa normal, por garantia
        mudaLayout("layoutNormal");
    }
}

function mudaLayout(valor) {
    switch(valor) {
        case "layoutNormal":
            document.body.style.backgroundColor = "#FFF";
            document.querySelector("main").style.backgroundColor = "#FAEBD7";            
            document.querySelector("header").style.backgroundColor = "#FFE7BA";

            elemento = document.querySelectorAll("section"), i;
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FAEBD7";
                }                
            }

            elemento = document.querySelectorAll("article"), i;
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FAEBD7";
                    elemento[i].style.border = "20px solid #FAEBD7";
                }
            }

            elemento = document.querySelectorAll("h1");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FAEBD7";
                    
                }
            }

            elemento = document.querySelectorAll("h2");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FAEBD7";
                    elemento[i].style.border = "20px solid #FAEBD7";
                }
            }

            elemento = document.querySelectorAll("h3");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FAEBD7";
                    elemento[i].style.border = "20px solid #FAEBD7";
                }
            }

            elemento = document.querySelectorAll("h4");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FAEBD7";
                    elemento[i].style.border = "20px solid #FAEBD7";
                }
            }

            //Fontes
            var divs = document.body.querySelectorAll("div"), i;
            for (i = 0; i < divs.length; ++i) {
                divs[i].style.fontFamily = "Helvetica Neue,Helvetica,Arial,sans-serif";
            }
            
            var labels = document.body.querySelectorAll("label"), i;
            for (i = 0; i < labels.length; ++i) {
                labels[i].style.fontFamily = "Helvetica Neue,Helvetica,Arial,sans-serif";
            }

            var articles = document.body.querySelectorAll("article"), i;
            for (i = 0; i < articles.length; ++i) {
                articles[i].style.fontFamily = "Helvetica Neue,Helvetica,Arial,sans-serif";
            }
            break;
        case "layoutCustom":
            //Cores
            document.body.style.backgroundColor = "#99CCFF";
            var elemento = document.querySelector("main");
            if (elemento != null) {
                elemento.style.backgroundColor = "#FFF";
            }
            
            elemento = document.querySelector("header");
            if (elemento != null) {
                elemento.style.backgroundColor = "#FFF";
            }

            elemento = document.querySelectorAll("section"), i;
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FFF";
                }                
            }

            elemento = document.querySelectorAll("article"), i;
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FFF";
                    elemento[i].style.border = "20px solid #FFF";
                }
            }

            elemento = document.querySelectorAll("h1");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FFF";
                    
                }
            }

            elemento = document.querySelectorAll("h2");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FFF";
                    elemento[i].style.border = "20px solid #FFF";
                }
            }

            elemento = document.querySelectorAll("h3");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FFF";
                    elemento[i].style.border = "20px solid #FFF";
                }
            }

            elemento = document.querySelectorAll("h4");
            if (elemento != null) {
                for (i = 0; i < elemento.length; ++i) {
                    elemento[i].style.backgroundColor = "#FFF";
                    elemento[i].style.border = "20px solid #FFF";
                }
            }

            //Fontes
            var divs = document.body.querySelectorAll("div"), i;
            for (i = 0; i < divs.length; ++i) {
                divs[i].style.fontFamily = "Times New Roman, Times, serif";
                divs[i].style.fontSize = 15;
            }
            
            var labels = document.body.querySelectorAll("label"), i;
            for (i = 0; i < labels.length; ++i) {
                labels[i].style.fontFamily = "Times New Roman, Times, serif";
                labels[i].style.fontSize = 15;
            }

            var articles = document.body.querySelectorAll("article"), i;
            for (i = 0; i < articles.length; ++i) {
                articles[i].style.fontFamily = "Times New Roman, Times, serif";
                articles[i].style.fontSize = 15;
            }
            break;
    }
}