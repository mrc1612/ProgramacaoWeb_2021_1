/**
 * Função responsavel por definir o tema
 */
function setTheme() {
    var selectTheme = document.getElementById('select_theme');
    var option = selectTheme.options[selectTheme.selectedIndex].value;
    document.cookie = `logged:true|theme:${option}|`;
    window.location.href = 'profile.html';
}

/**
 * Criando estilo
 */
var normalTheme = "";
var cssTextNormal = document.createTextNode(normalTheme);

var customTheme = "* {font-family: 'Roboto', sans-serif; color: white;}\n"
    + "input {color: black;}\n"
    + "button {color: black}\n"
    + "body {background: rgb(4, 4, 25);}\n"
    + "body main p, body main label, body main span {background: rgb(4, 4, 25); color: white;}\n"
    + "body select {color: black;}\n"
    + ".form span, .form a, .form p, .form span, .form label {color: white;}\n"
    + "footer {background: white;}\n"
    + "footer span {color: rgb(4, 4, 25);}";
var cssTextCustom = document.createTextNode(customTheme);

/**
 * Criando tag de estilo, que sera anexada ao cabecalho (head) da pagina
 * Adicionando atributos a tag de estilo
 */
var styleTag = document.createElement("style");
styleTag.type = "text/css";

/**
 * Obtendo o thema escolhido pelo usuario, que foi guardado dentro do cookie
 */
var arrayCookies = document.cookie.split("|");
var theme = "";
arrayCookies.map((cookie) => {
    if (cookie.length > 0 && cookie != "") {
        var keyCookie = cookie.split(":")[0];
        var valueCookie = cookie.split(":")[1];

        if (keyCookie == "theme") {
            theme = valueCookie;
        }
    }
});

/**
 * Anexando a tag de estilo o css (String que contem o estilo)
 * Definindo tema que sera apresentado
 */
if (theme == "custom") {
    styleTag.appendChild(cssTextCustom);

} else {
    styleTag.appendChild(cssTextNormal);

}

/**
 * Adicionando dentro do cabecalho (head) da pagina a tag de estilo (style)
 */
document.getElementsByTagName("head")[0].appendChild(styleTag);