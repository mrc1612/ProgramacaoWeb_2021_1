function validate() {
    var input_code = document.getElementById('input_code');
    var input_name = document.getElementById('input_name');
    var input_value = document.getElementById('input_value');
    var input_amount = document.getElementById('input_amount');

    if (input_code.value == '' || input_name.value == '' || input_amount.value == '' || input_value.value == '') {
        alert('Preencha corretamente todos os campos.');
    } else {
        create(input_code.value, input_name.value, input_amount.value, input_value.value);

        document.getElementById('input_code').value = '';
        document.getElementById('input_name').value = '';
        document.getElementById('input_value').value = '';
        document.getElementById('input_amount').value = '';
    }
}

function create(code, name, amount, value) {
    var parent = document.getElementById('table');

    var row = document.createElement('div');
    row.id = 'row-' + code;
    row.className = 'row';

    var action = document.createElement('div');
    action.className = 'action';
    action.id = 'action';

    var spanCode = document.createElement('span');
    var txtCode = document.createTextNode(code);

    var inputName = document.createElement('input');
    inputName.setAttribute('value', name);
    inputName.setAttribute('disabled', 'true');
    inputName.id = 'input_name' + code;

    var inputAmount = document.createElement('input');
    inputAmount.setAttribute('value', amount);
    inputAmount.setAttribute('disabled', 'true');
    inputAmount.setAttribute('type', 'number');
    inputAmount.id = 'input_amount' + code;

    var inputValue = document.createElement('input');
    inputValue.setAttribute('value', value);
    inputValue.setAttribute('disabled', 'true');
    inputValue.id = 'input_value' + code;

    var buttonEdit = document.createElement('button');
    buttonEdit.setAttribute('onclick', `edit('${code}')`)
    var txtEdit = document.createTextNode('Editar');

    var buttonDelete = document.createElement('button');
    buttonDelete.setAttribute('onclick', `destroy('${code}')`)
    var txtDelete = document.createTextNode('Deletar');

    spanCode.appendChild(txtCode);

    buttonEdit.appendChild(txtEdit);
    buttonDelete.appendChild(txtDelete);

    action.appendChild(buttonEdit);
    action.appendChild(buttonDelete);

    row.appendChild(spanCode);
    row.appendChild(inputName);
    row.appendChild(inputAmount);
    row.appendChild(inputValue);
    row.appendChild(action);

    parent.appendChild(row);
}

function edit(code) {
    var input_name = document.getElementById(`input_name${code}`);
    var input_amount = document.getElementById(`input_amount${code}`);
    var input_value = document.getElementById(`input_value${code}`);
    
    if (input_name.getAttribute('disabled') == 'true') {
        input_name.removeAttribute('disabled', 'false');
        input_value.removeAttribute('disabled', 'false');
        input_amount.removeAttribute('disabled', 'false');

    } else {
        if (input_name.value == '' || input_amount == '' || input_value == '') {
            alert('Preencha corretamente todos os campos antes de editar.');

        } else {
            input_name.setAttribute('disabled', 'true');
            input_value.setAttribute('disabled', 'true');
            input_amount.setAttribute('disabled', 'true');

        }
    }
}

function destroy(code) {
    var parent = document.getElementById('table');
    var row = document.getElementById(`row-${code}`);
    
    parent.removeChild(row);
}