/**
 * Uma alternativa para o uso de cookies é usar utilizar a classe LocalStorage
 * Que é semelhante a sessionStorage.
 */

/**
 * Função responsavel por verificar se há um usuario logado.
 * Procura dentro dos cookie's a string "logged" delimitada por ";"
 * Recupera o valor da string apos a igualdade (logged=true ou logged=false)
 * Caso exista sera criado no menu o item para "logoff" e a imagem de perfil.
 * Caso não exista sera adicionado ao menu o item "entrar" e o texto "Usuario não autentificado".
 */
function isLogged() {
    // let isLogged = localStorage.getItem('logged');
    let isLogged = document.cookie.split('; ')
        .find(row => row.startsWith('logged=')).split('=')[1];

    if (isLogged == 'true') {
        var menu = document.getElementById('menu');
        var perfil = document.getElementById('perfil');
    
        // Criando novos elementos
        var divLogout = document.createElement('div');
        var linkLogout = document.createElement('span');
        var divRegister = document.createElement('div');
        var linkRegister = document.createElement('a');
        var imgPerfil = document.createElement('img');
    
        // Criando "nos" de texto
        var logoutText = document.createTextNode('Sair');
        var registerText = document.createTextNode('Cadastro de produtos');
    
        // Definindo atributos dos elementos
        divLogout.setAttribute('class', 'menu-item');
        divLogout.onclick = () => logOut();
        divRegister.setAttribute('class', 'menu-item');
    
        // Linkando os elementos aos respectivos textos
        linkLogout.appendChild(logoutText);
        linkRegister.appendChild(registerText);
    
        // Definindo atributos dos elementos
        linkLogout.setAttribute('class', 'link');
        linkRegister.setAttribute('class', 'link');
        linkRegister.setAttribute('href', 'register.html');
        imgPerfil.setAttribute('src', './assets/anonymous.png');
        imgPerfil.setAttribute('alt', 'Me');
        imgPerfil.onclick = () => (window.location.href = 'profile.html');
    
        // Linkando os elementos aos respectivos elementos-pais
        divLogout.appendChild(linkLogout);
        divRegister.appendChild(linkRegister);
        menu.appendChild(divRegister);
        menu.appendChild(divLogout);
        perfil.appendChild(imgPerfil);
    
    } else {
        var menu = document.getElementById('menu');
        var perfil = document.getElementById('perfil');
    
        // Criando novos elementos
        var divLogin = document.createElement('div');
        var linkLogin = document.createElement('a');
        var spanPerfil = document.createElement('span');
    
        // Criando "nos" de texto
        var loginText = document.createTextNode('Entrar');
        var spanText = document.createTextNode('Usuario não autentificado.');
    
        // Definindo atributo do elemento
        divLogin.setAttribute('class', 'menu-item');
    
        // Linkando os elementos aos respectivos textos
        linkLogin.appendChild(loginText);
        spanPerfil.appendChild(spanText);
    
        // Definindo atributos dos elementos
        linkLogin.setAttribute('href', 'login.html');
        linkLogin.setAttribute('class', 'link');
        spanPerfil.setAttribute('class', 'no-user');
    
        // Linkando os elementos aos respectivos elementos-pais
        divLogin.appendChild(linkLogin);
        menu.appendChild(divLogin);
        perfil.appendChild(spanPerfil);
    }
}

/**
 * Função responsavel por recuperar dados do formulario de login.
 * Testar esses dados, caso sejam nulos e retornado uma mensagem.
 * Caso não, é criado dentro do cookie uma string (logged=true)
 * Que representa um usuario logado.
 * 
 * Caso não, e criado na variavel de ambiente (localStorage) um novo "nó".
 * Que representa um usuario logado.
 */

function setLogin() {
    var input_email = document.getElementById('input_email').value;
    var input_pass = document.getElementById('input_password').value;

    if (input_email == '' || input_pass == '') {
        alert('Preencha corretamente os campos.');
    } else {
        // localStorage.setItem('logged', true);
        document.cookie = 'logged=true';
        window.location.href = 'index.html';
    }
}

/**
 * Função responsavel por "deslogar" o usuario.
 * Altera o valor do cookie (logged=false)
 * Limpa a variavel de ambiente (localStorage) e redireciona a pagina inicial.
 */
function logOut() {
    // localStorage.clear();
    document.cookie = 'logged=false';
    window.location.href = 'index.html';
    alert('Good Bye');
}